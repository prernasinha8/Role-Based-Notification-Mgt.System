<?php $__env->startSection('content'); ?>
<form  class="form-inline" action="<?php echo e(url('/information-action')); ?>"   method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

										 <div class="col-md-6">
					<div class="md-form">
                    <input type="hidden" name="approve"  class="form-control" value="1" />
                    
				</div></div>
                    <div class="col-md-6">
					<button class="btn btn-success my-4 waves-effect waves-light pull-right">Approve</button>
				</div>
</form>
<form  class="form-inline" action="<?php echo e(url('/reject-action')); ?>"   method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

										 <div class="col-md-6">
					<div class="md-form">
                    <input type="hidden" name="Reject"  class="form-control" value="0" />
                    
				</div></div>
                    <div class="col-md-6">
					<button class="btn btn-success my-4 waves-effect waves-light pull-left">REJECT</button>
				</div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>