<?php $__env->startSection('content'); ?>

<div class="container">
<div class="row justify-content-center">
<div class="col-md-8">
<div class="card">
<div class="form-group">
<div class="md-form">
<form  class="form-inline" action="<?php echo e(url('/searchbyname')); ?>"   method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
    <label for="name">search by name:</label>
    <input type="text" class="form-control" id="name" placeholder="search by name" name="name">
    <button  type="submit" name="button" class="btn btn-primary mb-2 waves-effect waves-light">Search<i class="fas fa-send ml-1"></i></button>
      </div>
      </form>
     <div class="md-form">
<form class="form-inline" action="<?php echo e(url('/searchbydate')); ?>"   method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    
<div class="md-form">
<label for="name">search by date:</label>
      <label for="date">start_date</label>
      <input  type="date" name="start_date" id="date-picker-example" class="form-control datepicker">
      </div>
      <div class="md-form">
      <label for="date">End_date</label>
      <input  type="date" name="End_date" id="date-picker-example" class="form-control datepicker">
      </div>
       <button  type="submit" name="mysubmit" class="btn btn-primary mb-2 waves-effect waves-light">Search<i class="fas fa-send ml-1"></i></button>
      <?php echo csrf_field(); ?>
      </form>
 
            
      




<div class="card-header">Upload File</div>
<div class="card-body">
<form action="<?php echo e(url('/savefile')); ?>" method="post" enctype="multipart/form-data">
   <?php echo csrf_field(); ?>
     <?php if(Session::has('message')): ?>
	    <div class="alert alert-success"><?php echo e(Session::get('message')); ?></div>
    <?php endif; ?>
           <?php if($errors->any()): ?>
             <div class="alert alert-danger">
              <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <li><?php echo e($error); ?></li>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    </div>
           <?php endif; ?>
             <input type="file" name="file" id="file" class="form-control">
              
             <?php echo csrf_field(); ?>
          <div class="text-center mt-1-half">
        <button class="btn btn-info mb-2 waves-effect waves-light">Send <i class="fas fa-send ml-1"></i></button>
    </form>
    </div>
     </div>
  </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>