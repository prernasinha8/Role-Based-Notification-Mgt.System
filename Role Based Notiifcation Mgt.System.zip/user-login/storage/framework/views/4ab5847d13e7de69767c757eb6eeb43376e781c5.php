<?php $__env->startSection('content'); ?>
<form  class="form-inline" action="<?php echo e(url('/vendor-action')); ?>"   method="post" enctype="multipart/form-data">
 <?php echo e(csrf_field()); ?>

 <?php if(Session::has('message')): ?>
	    <div class="alert alert-success"><?php echo e(Session::get('message')); ?></div>
    <?php endif; ?>

        <input type="hidden" name="status"  id="status"  value="1" />
        <div class="col-md-6">
        <?php if(Auth::user()->id == 6): ?>

        <button class="btn btn-success my-4 waves-effect waves-light "id="Approve" style="float:right">Approve</button>

       <?php else: ?>
       <?php endif; ?>
       </div>
        
     
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>