<?php $__env->startSection('content'); ?>

<html>
 <head>
  <title>Live search in laravel using AJAX</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 </head>
 <body>
  <br />
  <div class="container box">
   
   <div class="panel panel-default">
    <div class="panel-heading">Search User Data</div>
    <div class="panel-body">
     <div class="form-group">
      <input type="text" name="search" id="search" class="form-control" placeholder="Search user Data" />
     </div>
     <div class="table-responsive">
<table class="table table-striped table-bordered">
       <thead>
        <tr>
         <th>user id</th>
         <th>file</th>
         <th>status</th>
         <th>created at</th>
         <th>updated at</th>
        </tr>
       </thead>
       <tbody>

       </tbody>
      </table>
     </div>
    </div>    
   </div>
  </div>
 </body>
</html>

<script>
$(document).ready(function(){

 fetch_customer_data();

 function fetch_customer_data(query = '')
 {
  $.ajax({
    url : '<?php echo e(URL::to('search')); ?>',
   method:'GET',
   data:{query:query},
   dataType:'json',
   success:function(data)
   {
    $('tbody').html(data.table_data);
    $('#total_records').text(data.total_data);
   }
  })
 }

 $(document).on('keyup', '#search', function(){
  var query = $(this).val();
  fetch_customer_data(query);
 });
});
</script>




 <?php if(Session::has('message')): ?>
 	<div class="alert alert-success"><?php echo e(Session::get('message')); ?></div>
  <?php endif; ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                    <label for="file" class="active">Upload file</label>
           <form action="<?php echo e(url('/savefile')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
            <div class="md-form form-sm">
                    <i class="fas fa-lock prefix active"></i>
                    <?php if($errors->any()): ?>
                  <div class="alert alert-danger">
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </ul>
             </div>
                  <?php endif; ?>
                 <input type="file" name="file" id="file" class="form-control">
                 </div>
                 <?php echo csrf_field(); ?>
                <div class="text-center mt-1-half">
        <button class="btn btn-info mb-2 waves-effect waves-light">Send <i class="fas fa-send ml-1"></i></button>
       </form>
        </div>
        </div>
        </div>
        </div>
        </div>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>