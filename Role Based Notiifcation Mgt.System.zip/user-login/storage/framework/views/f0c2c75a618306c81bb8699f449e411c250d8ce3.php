<!DOCTYPE html>
<html>
<!-- Styles -->
<link href="<?php echo e(url('/assets/css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('/assets/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('/assets/css/addons/datatables.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
     <link href= "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    
    
    <!-- Scripts -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="<?php echo e(url('/assets/js/bootstrap.js')); ?>" defer></script>
    <script src="<?php echo e(url('/assets/js/mdb.js')); ?>" defer></script>
    <script src="<?php echo e(url('/assets/js/popper.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

	<!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">

    
<head>
</head>
<body>
	<form  class="form-inline" action="<?php echo e(url('/notice-action')); ?>"   method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

					<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>			
					

<div class="container">

<div class="col-lg-12 ">
	<section class="mb-4">
	<br>
 <div class="card">
 
   <div class="card-body">
	 <h4 class="">Add New RFQ <small><span class="pull-right"></h4>
	 
   </div>
 </div>
</section>
<div class="card">
   <div class="card-body ">
   <div class="form-row">
   <div class="col-md-6">

<div class="md-form">

<select class="mdb-select md-form" name="vendor_id" id="vendor_id" require>

																							
			  <option value="6" selected >himanshi Aggarwal(himanshiaggarwal40@gmail.com)</option>
  
																														 

																 </select>
<label for="vendor" class="active"><sup style="color:#F00;">*</sup> Vendor name </label>
<div class="invalid-feedback" id="approved_by">
		   Please choose a Vendor
</div>
</div>


					
					
		<div class="col-md-6">

                <div class="md-form">
               
                <select class="mdb-select md-form" name="approved_id" id="approved_by" require>

                                                      	                 	 	                		
                  			<option value="3" selected >Richa(rajricha1993@gmail.com)</option>
                  
                 		                                                          	                 	 	                		
                  			<option value="2"  >Prerna sinha(arpitasood036@gmail.com)</option>
                  
                 		                                                        </select>
                <label for="approved_by" class="active"><sup style="color:#F00;">*</sup> Approved By</label>
                <div class="invalid-feedback" id="approved_by">
                           Please choose a Approved By.
                </div>
                </div>


	   
				<div class="col-md-6">
					<div class="md-form">
					<input type="text"  class="form-control" name="Category_name" style="margin-top:50px; width:500px;"  placeholder="Category Name">
				</div></div>
   
	   
						<div class="col-md-6">
					<div class="md-form">
					<input type="text"  class="form-control"  name="Item_name" style="margin-top:50px; width:500px;" placeholder="Item name">
				</div></div>
   
				<div class="col-md-6">
					<div class="md-form">
					<input type="text"  class="form-control" name="Unit_size"  style="margin-top:50px; width:500px;"placeholder="Unit Size" >
				</div></div>
   
   					<div class="col-md-6">
					<div class="md-form">
				<input type="text" class="form-control"  name="Catalogue_num" style="margin-top:50px; width:500px;" placeholder=" Catalogue Num">
				</div></div>
				<div class="col-md-6">
				<input type="hidden" name="notifications"  id="notifications"  value="1" />
					<button class="btn btn-success my-4 waves-effect waves-light pull-right" id="send">Send</button>
				</div>
				</div>
				</div>
				</form>
				</body>
				
</html>				




