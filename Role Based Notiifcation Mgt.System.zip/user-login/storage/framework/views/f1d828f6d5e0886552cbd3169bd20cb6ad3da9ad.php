<!DOCTYPE html>
<html>
<head>
<body>


<div class="modal-dialog">
        <div class="modal-content">
        <form action="<?php echo e(url('/findhere')); ?>" method="post" enctype="multipart/form-data"> 
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
            <label>Search Here</label>
                <input type="text" name="Find_here" class="form-control" />
                         </div>
                    <button type="submit" name="submit" value="search">Search</button>  
                </div>
            </div>
        </form>
    </body>
    </head>
</html>