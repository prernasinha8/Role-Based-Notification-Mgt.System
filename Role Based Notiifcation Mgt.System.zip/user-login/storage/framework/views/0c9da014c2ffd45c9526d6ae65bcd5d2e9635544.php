<?php $__env->startSection('content'); ?>

<form  class="form-inline" action="<?php echo e(url('/quotation-action')); ?>"   method="post" enctype="multipart/form-data">
                  <?php echo e(csrf_field()); ?>

</form>
				  <form  class="form-inline" action="<?php echo e(url('/approve-quotation')); ?>"   method="post" enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

    
<div class="container">
      <div class="col-lg-12 ">
	<section class="mb-4">
	<br>
 <div class="card">
 
   <div class="card-body">
	 <h4 class="">New Quotation<small><span class="pull-right"></h4>
	 
   </div>
 </div>
</section>
<div class="card">
   <div class="card-body ">
   <div class="form-row">
 <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <div class="col-md-6">
   <div class="md-form">
<input type="text"  class="form-control" name="Vendor_name" value="<?php echo e($list->Vendor_id); ?>" style="margin-top:50px; width:500px;" placeholder="Vendor Name">
		</div></div>

    <div class="col-md-6">
   <div class="md-form">
<input type="text"  class="form-control" name="Approver_name" value="<?php echo e($list->Approver_id); ?>" style="margin-top:50px; width:500px;" placeholder="Vendor Name">
		</div></div>

<div class="col-md-6">
					<div class="md-form">
					<input type="text"  class="form-control" name="Category_name" value="<?php echo e($list->Category_name); ?>" style="margin-top:50px; width:500px;"  placeholder="Category Name">
				</div></div>
   
	   
						<div class="col-md-6">
					<div class="md-form">
					<input type="text"  class="form-control"  name="Item_name"  value="<?php echo e($list->Item_name); ?>" style="margin-top:50px; width:500px;" placeholder="Item name">
				</div></div>
   
				<div class="col-md-6">
					<div class="md-form">
					<input type="text"  class="form-control" name="Unit_size" value="<?php echo e($list->Unit_size); ?>" style="margin-top:50px; width:500px;"placeholder="Unit Size" >
				</div></div>
   
   					<div class="col-md-6">
					<div class="md-form">
				<input type="text" class="form-control"  name="Catalogue_num" value="<?php echo e($list->Catalogue_num); ?>" style="margin-top:50px; width:500px;" placeholder=" Catalogue Num">
				</div></div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
 <input type="hidden" name="notification_id" value="<?php echo e(Request::segment(2)); ?>"/> 
    <input type="hidden" name="status"  id="status"  value="1" />
        <div class="col-md-6">
      
        <button class="btn btn-success my-4 waves-effect waves-light "id="Approve" style="float:right">Send Quotation</button>
      
       </div>
      </form>
<form  class="form-inline" action="<?php echo e(url('/reject-quotation')); ?>"   method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

        <input type="hidden" name="status"  id="status"  value="0" />
        <input type="hidden" name="notification_id" value="<?php echo e(Request::segment(2)); ?>"/> 
        <div class="col-md-6">

        <button class="btn btn-danger my-4 waves-effect waves-light " id="Reject" style="float:left; dispaly:block" >Reject RFQ</button>

        </div>

</form>
<?php $__env->stopSection(); ?>
  
            

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>