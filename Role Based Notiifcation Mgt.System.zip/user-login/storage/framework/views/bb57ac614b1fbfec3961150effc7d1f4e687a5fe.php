<!DOCTYPE html>
<html>
<head>
</head>


<body>
	<div class="container">
		
<form  class="form-inline" action="<?php echo e(url('/notice-action')); ?>"   method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>


					<table class="table table-striped table-bordered">
      <tr>
      <th>id</th>
      <th>data</th>
      <th>read_at</th>
      </tr>

					<?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr> 
                  <td><?php echo e($list->id); ?></td>
                  <td><?php echo e($list->data); ?></td>
                  <td><?php echo e($list->read_at); ?></td>
            </tr>
</table>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
     
        
			<div class="row">
				<div class="col-md-6">
				
					<h1><input type="text" name="data" class="form-control"></h1>
				</div>
				<div class="col-md-6">
					<button class="btn btn-success">Send</button>
				</div>
				</div>
				</form>


				
</body>
</html>


 

	