<?php
use App\User;
 use App\Notifications\Bell;
 
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
   
    $user=User::find(1);
    $user->notify(new Bell()); 
    return view('welcome');
});



Route::get('markAsRead',function() {
auth()->user()->unreadNotifications->markAsRead();
return redirect()->back();
})->name('markRead');



Auth::routes(['verify' => true]);
Route::get('profile', function () {
    // Only verified users may enter...
})->middleware('verified');


Route::get('/home', 'HomeController@index')->name('home');
Route::get('/uploadfile', 'HomeController@uploadfile')->name('uploadfile');
Route::post('/savefile', 'HomeController@SaveFile')->name('savefile');


Route::post('/searchbydate','HomeController@searchbydate') ->name('searchbydate');
Route::post('/searchbyname','HomeController@searchbyname') ->name('searchbyname');

Route::get('/userdata', 'HomeController@userdata')->name('userdata');
Route::get('/getdata', 'HomeController@getdata')->name('getdata');
Route::post('/postdata', 'HomeController@postdata')->name('postdata');

Route::get('/join', 'HomeController@join')->name('join');
Route::get('/authenticate', 'Auth\LoginController@authenticate')->name('authenticate');

Route::get('/find', 'HomeController@find')->name('find');
Route::post('/findhere', 'HomeController@findhere')->name('findhere');


Route::get('/notice', 'HomeController@notice')->name('notice');
Route::post('/notice-action', 'HomeController@noticeAction')->name('notice-action');
Route::get('/approve-notification/{id}','HomeController@MarkasRead');
Route::post('/approve-action', 'HomeController@approveAction');
Route::post('/reject-action', 'HomeController@rejectAction');
Route::get('/approve-Action/{id}', 'HomeController@approveRfqAction');
Route::get('/reject-Action/{id}', 'HomeController@rejectRfqAction');
Route::get('/quotation-action/{id}', 'HomeController@VendorAction')->name('quotation-action');
Route::post('/approve-quotation', 'HomeController@approveQuotationAction');
Route::post('/reject-quotation', 'HomeController@rejectQuotationAction');
Route::get('/approve-RFQ/{id}', 'HomeController@approveQuotationAction2');
Route::get('/reject-Action/{id}', 'HomeController@rejectQuotationAction2');

