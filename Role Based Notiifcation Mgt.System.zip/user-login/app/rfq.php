<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class rfq extends Model
{
    protected $table = 'rfq';
    protected $fillable = [
        'id','user_id', 'Vendor_name','Approver_name','Category_name','Item_name','Unit_size','Catalogue_num',
    ];  
}
