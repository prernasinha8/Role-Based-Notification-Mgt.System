<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class notifications extends Model
{
    protected $table = 'notifications';
    protected $fillable = [
        'type','notification_type', 'notification_id','data','rfq_status','read_at','created_at','updated_at',
    ];
}
