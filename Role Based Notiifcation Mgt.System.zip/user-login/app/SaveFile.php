<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SaveFile extends Model
{
    protected $table = 'save_file';
    protected $fillable = [
        'user_id','file', 'status',
    ];
}
