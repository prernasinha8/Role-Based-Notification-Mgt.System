<?php

namespace App;

use Nicolaslopezj\Searchable\SearchableTrait;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Order;

class User extends Authenticatable implements MustVerifyEmail
{
     use Notifiable;
     use SearchableTrait;


   /*  protected $searchableColumns = [
        'columns' => [
            'users.name' => 10,
            'users.email' => 5,
            'users.id' => 3,
        ]
    ];*/

protected $searchableColumns = [
  'columns' =>  [
        'users.name' => 10,
        'users.email' => 5,
        'users.id' => 3,
        'orders.name' => 5,
        'orders.order_num' => 2,
        'orders.item_name' => 1,

        ],
        'joins' => [
            'orders' => ['users.id','orders.user_id'],
        ],
        ];
        public function Order()
        {
            return $this->hasMany('App\Order'); 
//return $this->hasMany(Order::class); 
        }
    


/**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

}

    