<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use File;
use Illuminate\Support\Facades\Input;
use DB;
use Redirect;
use App\SaveFile;
use App\User;
use App\Order;
use App\Notifications;
use DataTables;
use Hash;
use Illuminate\Support\Facades\Auth; 
use Illuminate\Support\Facades\validator;
use App\Notifications\Bell;
use App\Notifications\Approve;
use App\Notifications\Reject;
use App\Notifications\quotation;
use App\Notifications\QuotationApprove;
use App\Notifications\QuotationReject;
class HomeController extends Controller
{
/**
 * Create a new controller instance.
 *
 * @return void
 */
public function __construct()
{
$this->middleware(['auth','verified']);
}

/**
* Show the application dashboard.
*
* @return \Illuminate\Contracts\Support\Renderable
*/
public function index()
{

return view('home');
}
public function uploadfile(Request $request)
{

$userlist = User::get();
//dd($userlist);
return view('upload_file', compact('userlist'));
}
public function SaveFile(Request $request)
{

$validatedData = $request->validate
([
'file' => 'required|mimes:docx,pdf',
]);
$file = $request->file('file');
$user_id =  auth()->user()->id;
if($request->file('file'))
{
$file = $request->file('file');
$fileimg = $file->getClientOriginalName();
$destinationPath = base_path().'/img';
$filemove = $file->move($destinationPath, $fileimg);
SaveFile::insert
(
['user_id' => $user_id , 'file' => $fileimg, 'status' => 1, ]
);
$request->session()->flash('message', 'FILE IS SUCCESSFULLY UPLOADED');
return redirect('/uploadfile');
}
}
public function searchbydate(Request $request)
{

//dd($request->start_date);
$date = DB::table('users')
  ->whereBetween('created_at', [$request->start_date, $request->End_date])->get();
  //dd($date);
  $find_user=array();
return view('search-result', compact('date','find_user'));
}
public function searchbyname(Request $request)
{
$date=array();
$find_user = User::where('name',$request->name)->get();
//dd($find_user)
return view('search-result', compact('find_user','date'));

}
public function userdata()
{
return view('user_data');

}

public function getdata()
{
$user =SaveFile::select('user_id', 'file','status');
return DataTables::of($user)->make(true);
}

public  function postdata(Request $request)
{


$validation = Validator::make($request->all(), [

'user_id'=>'required',  
'file' => 'required|mimes:docx,pdf',
'status'=>'required',
]);
$error_array = array();
$success_output = '';
if ($validation->fails())
{
foreach($validation->messages()->getMessages() as $field_name => $messages)
{
  $error_array[] = $messages;
}
}
else
{
$file = $request->file('file');
$user_id =  auth()->user()->id;
if($request->file('file'))
{
$file = $request->file('file');
$fileimg = $file->getClientOriginalName();
$destinationPath = base_path().'/img';
$filemove = $file->move($destinationPath, $fileimg);
SaveFile::insert
(
  ['user_id' => $user_id ,'file' => $fileimg,'status' => 1, ]
);
$request->session()->flash('message', 'DATA IS SUCCESSFULLY INSERTED');
return redirect('/userdata');
}
$output = array(
'error'     =>  $error_array,
'success'   =>  $success_output
);
echo json_encode($output);
}

}
public function join()
{
$data =  DB::table('users')
->join('user_details', 'users.id', '=', 'user_details.user-id')
->join('orders', 'users.id', '=', 'orders.user_id')
->where('users.id', '=' ,'2')
->select('users.name','users.email','users.id','user_details.age','orders.order_num','orders.item_name')
->get()->toArray();
foreach($data as $v)           
{
  $v->orders= DB::table('orders')->where('user_id','=',$v->id)->get()-> toArray();
}
echo"<pre>";
dd($data);
}
public function find(Request $request)
{

return view('my_search');

}
public function findhere(Request $request)
{
$users = User::with('Order',$request->Find_here)->get();
// $users = User::with('Order')->get();

return view('my_search', compact('users'));

/* $users = User::search($request->Find_here)
->with('orders')
->get();
dd($users);
return view('my_search',compact('users'));*/
}



public function notice(Request $request)
{
// dd($request);
  return view('notifications');
}

public function MarkasRead(Request $request)
{
  $notification_single = auth()->user()->notifications()->find($request->id);
    if($notification_single)
      {
        $notifications = notifications :: all();
        $users =DB::table('rfq')->select('*')->get();
        $rfq_status ='';
        $quotation_status='';
                    // dd($users);
                    //  $notification_single->markAsRead();
                      // dd($request->id);
        $request->session()->flash('message', 'New rfq from abc lab is generated and an action is required ');
        return view('notice',compact('notifications', 'notification_single','users','rfq_status','quotation_status'));
      }
}


public function noticeAction(Request $request)
{
        //dd($request);
        $user_id = Auth::id();
        $Vendor_id = $request->vendor_id;
        $Approver_id = $request->approved_id;
        $Category_name = $request->Category_name;
        $Item_name = $request->Item_name;
        $Unit_size = $request->Unit_size;
        $Catalogue_num = $request->Catalogue_num;

        $data=array('user_id'=>$user_id,'Vendor_id'=>$Vendor_id,"Approver_id"=>$Approver_id,"Category_name"=>$Category_name,
        "Item_name"=>$Item_name,"Unit_size"=>$Unit_size,"Catalogue_num"=>$Catalogue_num,);
        DB::table('rfq')->insert($data);


        $approver = User::find($Approver_id );
        $vendor = User::find($Vendor_id );
        $approver->notify(new Bell());
        $vendor->notify(new quotation());
       
        return redirect()->back()->with('success','RFQ HAS BEEN SUCCESSFULLY GENERATED AND SEND FOR THE APPROVAL');  
}


public function approveAction(Request $request)
{
    $rfq_status = Input::get('status');
    $notice_id = $request->notification_id;
    $notification_single = auth()->user()->notifications()->find($notice_id);
    if($notification_single)
    {
      $notification_single->markAsRead();
    }
    $user = User::where('id','<>', Auth::id())
    ->get();
    foreach($user as $userList)
    {
      $userList->notify(new Approve($rfq_status));
    }
    $request->session()->flash('message','RFQ has been Approved Successfully ');
    return view('approverfq',compact('rfq_status','notification_single'));
}


public function approveRfqAction(Request $request)
{
    $rfq_status = Input::get('status');
    $notice_id = $request->id;
    $notification_single = auth()->user()->notifications()->find($notice_id);
    if($notification_single)
    {
      $notification_single->markAsRead();
    }
    $user = User::where('id','<>', Auth::id())
    ->get();
    foreach($user as $userList)
    {
    $userList->notify(new Approve($rfq_status));
    }
    $request->session()->flash('message','RFQ has been Approved Successfully ');
    return view('approverfq',compact('rfq_status','notification_single'));
}




public function rejectAction(Request $request)
{
    $rfq_status = Input::get('status');
    $notice_id = $request->notification_id;
    //dd($notice_id);
    $notification_single = auth()->user()->notifications()->find($notice_id);
    if($notification_single)
    {
        $notification_single->markAsRead();
    }
    $user = User::where('id','<>', Auth::id())
    ->get();
    foreach($user as $userList)
    {
        $userList->notify(new Reject($rfq_status));
    }
    $request->session()->flash('message','RFQ has been Successfully Rejected ');
    return view('rejectrfq',compact('rfq_status','notification_single'));
}


public function rejectRfqAction(Request $request)
{
  $rfq_status = Input::get('status');
  $notice_id = $request->id;
  $notification_single = auth()->user()->notifications()->find($notice_id);
  if($notification_single)
  {
      $notification_single->markAsRead();
  }
  $user = User::where('id','<>', Auth::id())
  ->get();
  foreach($user as $userList)
  {
      $userList->notify(new Approve($rfq_status));
  }
  $request->session()->flash('message','RFQ has been Rejected Successfully ');
  return view('rejectrfq',compact('rfq_status','notification_single'));
}

public function VendorAction(Request $request)
{
        //dd($request);
        $user_id = Auth::id();
        $Vendor_id = $request->vendor_id;
        $Approver_id = $request->approved_id;
        $Category_name = $request->Category_name;
        $Item_name = $request->Item_name;
        $Unit_size = $request->Unit_size;
        $Catalogue_num = $request->Catalogue_num;

        $data=array('user_id'=>$user_id,'Vendor_id'=>$Vendor_id,"Approver_id"=>$Approver_id,"Category_name"=>$Category_name,
        "Item_name"=>$Item_name,"Unit_size"=>$Unit_size,"Catalogue_num"=>$Catalogue_num,);
        DB::table('rfq')->insert($data);

        $users = DB::table('rfq')->where('Vendor_id', Auth::id())->get();

      //  $request->session()->flash('message','quotation is successfully generated');
        return view('quotation', compact('users'));
       
}
public function approveQuotationAction(Request $request)
{
    $quotation_status = Input::get('status');
    $notice_id = $request->notification_id;
    $notification_single = auth()->user()->notifications()->find($notice_id);
    if($notification_single)
    {
      $notification_single->markAsRead();
    }
    $user = User::where('id','<>', Auth::id())
    ->get();
    foreach($user as $userList)
    {
      $userList->notify(new QuotationApprove($quotation_status));
    }
      $request->session()->flash('message','RFQ has been approved and a quotation is generated by the lab ');
      return view('ApproveQuotation',compact('quotation_status','notification_single'));
}
public function approveQuotationAction2(Request $request)
{
    $quotation_status = Input::get('status');
    $notice_id = $request->id;
    $notification_single = auth()->user()->notifications()->find($notice_id);
    if($notification_single)
    {
      $notification_single->markAsRead();
    }
    $user = User::where('id','<>', Auth::id())
    ->get();
    foreach($user as $userList)
    {
      $userList->notify(new QuotationApprove($quotation_status));
    }
      $request->session()->flash('message','RFQ has been approved and a quotation is generated by the lab ');
      return view('ApproveQuotation',compact('quotation_status','notification_single'));

  }

public function rejectQuotationAction(Request $request)
{
$quotation_status = Input::get('status');
$notice_id = $request->notification_id;
$notification_single = auth()->user()->notifications()->find($notice_id);
if($notification_single)
{
$notification_single->markAsRead();
}
$user = User::where('id','<>', Auth::id())
->get();
foreach($user as $userList)
{
  $userList->notify(new QuotationReject($quotation_status));
}
  $request->session()->flash('message','RFQ has been rejected by the vendor  quotation can not be genertaed ');
  return view('RejectQuotation',compact('quotation_status','notification_single'));
}

public function rejectQuotationAction2(Request $request)
{
$quotation_status = Input::get('status');
$notice_id = $request->id;
$notification_single = auth()->user()->notifications()->find($notice_id);
if($notification_single)
{
$notification_single->markAsRead();
}
$user = User::where('id','<>', Auth::id())
->get();
foreach($user as $userList)
{
  $userList->notify(new QuotationReject($quotation_status));
}
  $request->session()->flash('message','RFQ has been rejected by the vendor  quotation can not be genertaed ');
  return view('RejectQuotation',compact('quotation_status','notification_single'));
}


}














