@extends('layouts.app')
@section('content')
<form  class="form-inline" action="{{url('/reject-action')}}"   method="post" enctype="multipart/form-data">
            {{csrf_field()}}
            @if (Session::has('message'))
	    <div class="alert alert-success">{{ Session::get('message') }}</div>
    @endif

</form>
@endsection   