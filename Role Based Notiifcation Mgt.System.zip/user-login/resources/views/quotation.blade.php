@extends('layouts.app')
@section('content')

<form  class="form-inline" action="{{url('/quotation-action')}}"   method="post" enctype="multipart/form-data">
                  {{csrf_field()}}
</form>
				  <form  class="form-inline" action="{{url('/approve-quotation')}}"   method="post" enctype="multipart/form-data">
      {{csrf_field()}}
    
<div class="container">
      <div class="col-lg-12 ">
	<section class="mb-4">
	<br>
 <div class="card">
 
   <div class="card-body">
	 <h4 class="">New Quotation<small><span class="pull-right"></h4>
	 
   </div>
 </div>
</section>
<div class="card">
   <div class="card-body ">
   <div class="form-row">
 @foreach($users as $list)
   <div class="col-md-6">
   <div class="md-form">
<input type="text"  class="form-control" name="Vendor_name" value="{{$list->Vendor_id}}" style="margin-top:50px; width:500px;" placeholder="Vendor Name">
		</div></div>

    <div class="col-md-6">
   <div class="md-form">
<input type="text"  class="form-control" name="Approver_name" value="{{$list->Approver_id}}" style="margin-top:50px; width:500px;" placeholder="Vendor Name">
		</div></div>

<div class="col-md-6">
					<div class="md-form">
					<input type="text"  class="form-control" name="Category_name" value="{{$list->Category_name}}" style="margin-top:50px; width:500px;"  placeholder="Category Name">
				</div></div>
   
	   
						<div class="col-md-6">
					<div class="md-form">
					<input type="text"  class="form-control"  name="Item_name"  value="{{$list->Item_name}}" style="margin-top:50px; width:500px;" placeholder="Item name">
				</div></div>
   
				<div class="col-md-6">
					<div class="md-form">
					<input type="text"  class="form-control" name="Unit_size" value="{{$list->Unit_size}}" style="margin-top:50px; width:500px;"placeholder="Unit Size" >
				</div></div>
   
   					<div class="col-md-6">
					<div class="md-form">
				<input type="text" class="form-control"  name="Catalogue_num" value="{{$list->Catalogue_num}}" style="margin-top:50px; width:500px;" placeholder=" Catalogue Num">
				</div></div>
				@endforeach
 
 <input type="hidden" name="notification_id" value="{{Request::segment(2)}}"/> 
    <input type="hidden" name="status"  id="status"  value="1" />
        <div class="col-md-6">
      
        <button class="btn btn-success my-4 waves-effect waves-light "id="Approve" style="float:right">Send Quotation</button>
      
       </div>
      </form>
<form  class="form-inline" action="{{url('/reject-quotation')}}"   method="post" enctype="multipart/form-data">
            {{csrf_field()}}
        <input type="hidden" name="status"  id="status"  value="0" />
        <input type="hidden" name="notification_id" value="{{Request::segment(2)}}"/> 
        <div class="col-md-6">

        <button class="btn btn-danger my-4 waves-effect waves-light " id="Reject" style="float:left; dispaly:block" >Reject RFQ</button>

        </div>

</form>
@endsection
  
            
