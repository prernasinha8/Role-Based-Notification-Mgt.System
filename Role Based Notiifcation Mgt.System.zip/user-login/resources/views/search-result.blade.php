@extends('layouts.app')
@section('content')
<table class="table table-striped table-bordered">
      <tr>
      <th>Name</th>
      <th>Email</th>
      <th>Date</th>
      </tr>

    @if(count($find_user)>0)
            @foreach($find_user as $key=>$list)
            <tr> 
                  <td>{{$list->name}}</td>
                  <td>{{$list->email}}</td>
                  <td>{{ $list->created_at }}</td>
            </tr>
</table>
            @endforeach
            @endif
            @if(count($date)>0)
            @foreach($date as $key=>$list)
                   <tr>
                   <td>{{$list->name}}</td>
                  <td>{{$list->email}}</td>
                  <td>{{ $list->created_at }}</td>
                  </tr>
                  
            @endforeach
      @endif
            
     @endsection