<!DOCTYPE html>
<html>
<head>
</head>


<body>
	<div class="container">
		
<form  class="form-inline" action="{{url('/findhere')}}"   method="post" enctype="multipart/form-data">
                    {{csrf_field()}}
          
     
        
			<div class="row">
				<div class="col-md-6">
					<input type="text" name="Find_here" class="form-control" placeholder="Search here">
				</div>
				<div class="col-md-6">
					<button class="btn btn-success">Search</button>
				</div></form>
                
</div>
</body>
</html>

 

	