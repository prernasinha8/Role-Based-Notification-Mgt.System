@extends('layouts.app')
@section('content')

<form  class="form-inline" action="{{url('/notice-action')}}"   method="post" enctype="multipart/form-data">
                  {{csrf_field()}}
                   @if (Session::has('message'))
	    <div class="alert alert-success">{{ Session::get('message') }}</div>
    @endif
</form>

<form  class="form-inline" action="{{url('/approve-action')}}"   method="post" enctype="multipart/form-data">
      {{csrf_field()}}
      <div class="container">
      <div class="col-lg-12 ">
	<section class="mb-4">
	<br>
 <div class="card">
 
   <div class="card-body">
	 <h4 class="">Add New RFQ <small><span class="pull-right"></h4>
	 
   </div>
 </div>
</section>
<div class="card">
   <div class="card-body ">
   <div class="form-row">
 @foreach($users as $list)
   <div class="col-md-6">
   <div class="md-form">
<input type="text"  class="form-control" name="Vendor_name" value="{{$list->Vendor_id}}" style="margin-top:50px; width:500px;" placeholder="Vendor Name">
		</div></div>

    <div class="col-md-6">
   <div class="md-form">
<input type="text"  class="form-control" name="Approver_name" value="{{$list->Approver_id}}" style="margin-top:50px; width:500px;" placeholder="Vendor Name">
		</div></div>



		
		<div class="col-md-6">
					<div class="md-form">
					<input type="text"  class="form-control" name="Category_name" value="{{$list->Category_name}}" style="margin-top:50px; width:500px;"  placeholder="Category Name">
				</div></div>
   
	   
						<div class="col-md-6">
					<div class="md-form">
					<input type="text"  class="form-control"  name="Item_name"  value="{{$list->Item_name}}" style="margin-top:50px; width:500px;" placeholder="Item name">
				</div></div>
   
				<div class="col-md-6">
					<div class="md-form">
					<input type="text"  class="form-control" name="Unit_size" value="{{$list->Unit_size}}" style="margin-top:50px; width:500px;"placeholder="Unit Size" >
				</div></div>
   
   					<div class="col-md-6">
					<div class="md-form">
				<input type="text" class="form-control"  name="Catalogue_num" value="{{$list->Catalogue_num}}" style="margin-top:50px; width:500px;" placeholder=" Catalogue Num">
				</div></div>
@endforeach
 
 <input type="hidden" name="notification_id" value="{{Request::segment(2)}}"/> 
    <input type="hidden" name="status"  id="status"  value="1" />
        <div class="col-md-6">
       @if($notification_single->data['rfq_status'] == '')
        <button class="btn btn-success my-4 waves-effect waves-light "id="Approve" style="float:right">Approve</button>
       @elseif($notification_single->data['rfq_status'] == 1)
       @else
       @endif
       </div>
      </form>
<form  class="form-inline" action="{{url('/reject-action')}}"   method="post" enctype="multipart/form-data">
            {{csrf_field()}}
        <input type="hidden" name="status"  id="status"  value="0" />
        <input type="hidden" name="notification_id" value="{{Request::segment(2)}}"/> 
        <div class="col-md-6">
        @if($notification_single->data['rfq_status'] == '')
        <button class="btn btn-danger my-4 waves-effect waves-light " id="Reject" style="float:left; dispaly:block" >Reject</button>
        @elseif($notification_single->data['rfq_status'] == 0)
        @else
        @endif
        </div>

</form>
 @endsection
  
            
